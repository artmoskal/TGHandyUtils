"""Fanout-node handler: bounded parallel per-item execution with partial-failure isolation.

Mechanical split of the executor god-file (spec §2c#5). Handlers receive a narrow
``NodeExecutionServices`` boundary object (``services``) — never the executor itself.
"""
from __future__ import annotations
from typing import Any, Dict
from ai_workflow_engine.engine.capabilities import CapabilityCall, gather_capabilities
from ai_workflow_engine.models import CapabilityContext, CapabilityResult, RuntimeLimits, WorkflowTraceEvent

_DEFAULT_LIMITS = RuntimeLimits()
from ai_workflow_engine.workflow import WorkflowDefinition, WorkflowNode
from ai_workflow_engine._runtime_state import CONTEXT, RUNNING_PAYLOAD


def build_fanout_node(services, definition: WorkflowDefinition, node: WorkflowNode):
    item_capability = node.item_capability or node.capability or node.id

    async def fanout_fn(state: Dict[str, Any]) -> Dict[str, Any]:
        context: CapabilityContext = state[CONTEXT]
        # Fanout invokes the runtime directly for each item, so it must cross the same generic
        # node-context boundary as step/branch/planner nodes. This carries retrace provenance
        # and declared plan/machine injection without a fanout-specific approximation.
        context = services.context_for_node(
            node, context, state, definition=definition
        )
        items = _resolve_items(state, node)
        if not isinstance(items, list):
            failed = CapabilityResult(
                status="failed",
                error=f"fanout '{node.id}' items source '{node.fan_items_key}' is not a list",
            )
            return services.record(state, node, failed, attempts=1, input_payload=items)

        if node.max_items is not None and len(items) > node.max_items:
            # Declared structural bound (required on AI-authored fanout): refuse loudly,
            # NEVER truncate — silently processing a prefix would misreport coverage.
            failed = CapabilityResult(
                status="failed",
                error=(
                    f"fanout '{node.id}' received {len(items)} items, exceeding its declared "
                    f"max_items={node.max_items} — refusing to truncate"
                ),
            )
            return services.record(state, node, failed, attempts=1, input_payload=len(items))

        # R2: distinguish None (not set → profile bound) from a configured value — no falsy
        # `or` fallback may rewrite an explicit setting; the default comes from the MODEL.
        if node.max_parallel is not None:
            limit = node.max_parallel
        elif context.limits is not None:
            limit = context.limits.max_parallel_children
        else:
            limit = _DEFAULT_LIMITS.max_parallel_children
        calls = [CapabilityCall(item_capability, item) for item in items]
        results = await gather_capabilities(services.runtime, calls, context, max_parallel=limit)
        outputs = [r.output for r in results if r.status in ("accepted", "partial") and r.output is not None]
        accepted = [r for r in results if r.status == "accepted"]
        partials = [r for r in results if r.status == "partial"]
        failures = [r for r in results if r.status not in ("accepted", "partial")]
        # Partial-failure isolation: parent keeps successes; a wholesale failure halts. v0.10:
        # a timed-out child is PARTIAL (bounded work stopped), so a partial child keeps the
        # parent partial even without a hard failure — the incomplete work is never hidden.
        if failures and not (accepted or partials):
            status = "failed"
        elif failures or partials:
            status = "partial"
        else:
            status = "accepted"
        combined = CapabilityResult(
            status=status,
            output=outputs,
            artifacts=[artifact for r in results for artifact in r.artifacts],
            error=(
                "; ".join(r.error for r in (failures + partials) if r.error) or None
                if (failures or partials)
                else None
            ),
            metadata={
                "total": len(items),
                "succeeded": len(accepted),
                "partial": len(partials),
                "failed": len(failures),
            },
        )
        update = services.record(state, node, combined, attempts=1, input_payload=items)
        services.runtime.trace_sink.record(
            WorkflowTraceEvent(
                node=node.id,
                decision="fanout",
                metadata={
                    "total": len(items),
                    "succeeded": len(accepted),
                    "partial": len(partials),
                    "failed": len(failures),
                    "max_parallel": limit,
                },
            )
        )
        return update

    return fanout_fn

def _resolve_items(state: Dict[str, Any], node: WorkflowNode) -> Any:
    key = node.fan_items_key
    if not key:
        return state.get(RUNNING_PAYLOAD)
    parts = key.split(".")
    head = parts[0]
    value = state.get(RUNNING_PAYLOAD) if head == "payload" else state.get("node_outputs", {}).get(head)
    for attr in parts[1:]:
        if value is None:
            break
        value = value.get(attr) if isinstance(value, dict) else getattr(value, attr, None)
    return value
